/* MemGraph i18n — Uzbek (Latin) / Russian / English. Each key: [uz, ru, en] */
(function () {
  const D = {
    /* ---------- nav ---------- */
    'nav.features': ['Imkoniyatlar', 'Возможности', 'Features'],
    'nav.how': ['Qanday ishlaydi', 'Как это работает', 'How it works'],
    'nav.privacy': ['Maxfiylik', 'Приватность', 'Privacy'],
    'nav.pricing': ['Narxlar', 'Тарифы', 'Pricing'],
    'nav.faq': ['Savollar', 'Вопросы', 'FAQ'],
    'nav.login': ['Kirish', 'Войти', 'Log in'],
    'nav.signup': ['Roʻyxatdan oʻtish', 'Регистрация', 'Sign up'],
    'nav.open': ['Kabinetga oʻtish', 'Открыть кабинет', 'Open dashboard'],
    'nav.home': ['Umumiy koʻrinish', 'Обзор', 'Overview'],
    'nav.ask': ['Xotiradan soʻrash', 'Спросить память', 'Ask memory'],
    'nav.add': ['Xotira qoʻshish', 'Добавить в память', 'Add memory'],
    'nav.library': ['Kutubxona', 'Библиотека', 'Library'],
    'nav.graph': ['Bilimlar grafi', 'Граф знаний', 'Knowledge graph'],
    'nav.settings': ['Sozlamalar', 'Настройки', 'Settings'],
    'nav.logout': ['Chiqish', 'Выйти', 'Log out'],

    /* ---------- hero ---------- */
    'hero.badge': ['Privacy-First AI-xotira', 'AI-память с приватностью прежде всего', 'Privacy-first AI memory'],
    'hero.title': ['Sizning <em>ikkinchi miyangiz</em> — hech narsani unutmaydi', 'Ваш <em>второй мозг</em> — который ничего не забывает', 'Your <em>second brain</em> — that never forgets'],
    'hero.sub': ['Xatlar, qaydlar, PDF hujjatlar, uchrashuv yozuvlari va maqolalar avtomatik ravishda bitta bilimlar grafiga bogʻlanadi. Savol bering — 1 soniyada aniq, manbali javob oling.', 'Письма, заметки, PDF, записи встреч и статьи автоматически связываются в единый граф знаний. Задайте вопрос — и получите точный ответ с источниками за 1 секунду.', 'Emails, notes, PDFs, meeting transcripts and articles are linked into one knowledge graph automatically. Ask a question — get a precise, sourced answer in one second.'],
    'hero.cta1': ['Bepul boshlash', 'Начать бесплатно', 'Start for free'],
    'hero.cta2': ['Qanday ishlaydi?', 'Как это работает?', 'How does it work?'],
    'hero.note': ['Google orqali 10 soniyada roʻyxatdan oʻting', 'Регистрация через Google за 10 секунд', 'Sign up with Google in 10 seconds'],
    'demo.time': ['⚡ 1 soniya', '⚡ 1 секунда', '⚡ 1 second'],
    'demo.q': ['Oʻtgan oy B2B loyiha boʻyicha moliya va boʻlim boshligʻi bilan nima kelishgan edik?', 'Что мы согласовали в прошлом месяце по B2B-проекту с финансами и главой отдела?', 'What did we agree last month on the B2B project with finance and the department head?'],
    'demo.a': ['Byudjet 40 mln soʻmdan 52 mln soʻmgacha oshirildi, boʻlim boshligʻi pilotni 15-noyabrgacha ishga tushirishni talab qildi. Toʻlov 2 bosqichda amalga oshiriladi. [1][2]', 'Бюджет увеличен с 40 до 52 млн сумов, глава отдела потребовал запустить пилот до 15 ноября. Оплата в 2 этапа. [1][2]', 'The budget was raised from 40M to 52M UZS; the department head wants the pilot live by Nov 15. Payment in two stages. [1][2]'],
    'demo.s1': ['Xat: Moliya — byudjet', 'Письмо: Финансы — бюджет', 'Email: Finance — budget'],
    'demo.s2': ['Uchrashuv: B2B sync', 'Встреча: B2B sync', 'Meeting: B2B sync'],
    'prob.title': ['Biz oʻqigan maʼlumotning 90% unutiladi', '90% прочитанного мы забываем', '90% of what we read is forgotten'],
    'prob.sub': ['Notion va Obsidian kabi ilovalar tartiblashni sizning zimmangizga qoʻyadi. MemGraph esa hammasini oʻzi qiladi.', 'Notion и Obsidian перекладывают сортировку на вас. MemGraph делает всё сам.', 'Apps like Notion and Obsidian put the organizing on you. MemGraph does it all by itself.'],
    'prob.s1': ['maʼlumot odatda unutiladi', 'информации обычно забывается', 'of information is normally forgotten'],
    'prob.s2': ['ichida kontekstli javob', 'до контекстного ответа', 'to a contextual answer'],
    'prob.s3': ['qoʻlda tartiblash kerak emas', 'ручной сортировки не нужно', 'manual organizing needed'],
    'how.title': ['3 qadamda ikkinchi miya', 'Второй мозг в 3 шага', 'A second brain in 3 steps'],
    'how.sub': ['Oddiy, tez va hech qanday sozlashsiz.', 'Просто, быстро и без настройки.', 'Simple, fast and zero setup.'],
    'how.s1t': ['Qoʻshing', 'Добавьте', 'Add'],
    'how.s1d': ['Xat, qayd, PDF, havola yoki uchrashuv yozuvini joylang yoki fayl sifatida yuklang.', 'Вставьте письмо, заметку, ссылку или запись встречи, либо загрузите PDF и файлы.', 'Paste an email, note, link or meeting transcript, or upload PDFs and files.'],
    'how.s2t': ['Bogʻlanadi', 'Связывается', 'It links'],
    'how.s2d': ['MemGraph shaxs, tashkilot va mavzularni topib, hujjatlarni bilimlar grafiga ulaydi.', 'MemGraph находит людей, организации и темы и соединяет документы в граф знаний.', 'MemGraph finds people, organizations and topics and connects documents into a knowledge graph.'],
    'how.s3t': ['Soʻrang', 'Спрашивайте', 'Ask'],
    'how.s3d': ['Oddiy tilda savol bering — manbalari bilan aniq javob oling.', 'Задавайте вопросы обычным языком — получайте точные ответы с источниками.', 'Ask in plain language — get an exact answer with its sources.'],
    'feat.title': ['Hammasi bitta joyda', 'Всё в одном месте', 'Everything in one place'],
    'feat.sub': ['Raqamli hayotingiz uchun xotira infratuzilmasi.', 'Инфраструктура памяти для вашей цифровой жизни.', 'Memory infrastructure for your digital life.'],
    'f1t': ['Xatlar va qaydlar', 'Письма и заметки', 'Emails & notes'],
    'f1d': ['Xatlarni va qaydlarni joylang — ular qidiriladigan xotiraga aylanadi.', 'Вставляйте письма и заметки — они становятся памятью, по которой можно искать.', 'Paste emails and notes — they become searchable memory.'],
    'f2t': ['Maʼnoli qidiruv', 'Смысловой поиск', 'Semantic search'],
    'f2d': ['Aniq soʻz esingizda boʻlmasa ham maʼno boʻyicha topadi.', 'Находит по смыслу, даже если вы не помните точные слова.', 'Finds by meaning, even if you do not remember the exact words.'],
    'f3t': ['Bilimlar grafi', 'Граф знаний', 'Knowledge graph'],
    'f3d': ['Shaxslar, tashkilotlar va mavzular oʻrtasidagi aloqalarni koʻring.', 'Смотрите связи между людьми, организациями и темами.', 'See the connections between people, organizations and topics.'],
    'f4t': ['Uchrashuv yozuvlari', 'Записи встреч', 'Meeting transcripts'],
    'f4d': ['TXT, SRT, VTT transkriptlarni yuklang — kelishuvlar yoʻqolmaydi.', 'Загружайте TXT, SRT, VTT — договорённости больше не теряются.', 'Upload TXT, SRT, VTT transcripts — agreements never get lost.'],
    'f5t': ['Uch tilda', 'На трёх языках', 'Three languages'],
    'f5d': ['Oʻzbek, rus va ingliz tillarida ishlaydi — savol va hujjatlar ham.', 'Работает на узбекском, русском и английском — и вопросы, и документы.', 'Works in Uzbek, Russian and English — questions and documents alike.'],
    'f6t': ['Kompaniyalar uchun', 'Для компаний', 'For teams'],
    'f6d': ['Jamoaviy xotira, rollar va xavfsiz joylashtirish — kelishuv asosida.', 'Командная память, роли и безопасное развёртывание — по договорённости.', 'Shared team memory, roles and secure deployment — on request.'],
    'priv.title': ['Maxfiylik — birinchi oʻrinda', 'Приватность — прежде всего', 'Privacy comes first'],
    'priv.d': ['Xotira sizniki. Uni hech kim oʻqimaydi, reklama uchun ishlatilmaydi va modellarni oʻqitishda qatnashmaydi.', 'Память принадлежит вам. Её никто не читает, не использует для рекламы и не обучает на ней модели.', 'The memory is yours. Nobody reads it, it is not used for ads, and it never trains models.'],
    'priv.b1': ['Qidiruv va graf maʼlumotlaringiz serverda, oʻzingiznikida saqlanadi', 'Поиск и граф работают на вашем сервере, данные остаются у вас', 'Search and graph run on your own server — data stays with you'],
    'priv.b2': ['Istalgan payt hamma narsani JSON formatida yuklab oling', 'Выгрузите всё в JSON в любой момент', 'Export everything as JSON any time'],
    'priv.b3': ['Hisobni bitta tugma bilan butunlay oʻchiring', 'Удалите аккаунт и все данные одной кнопкой', 'Delete your account and all data with one button'],
    'priv.v1': ['Sizning xotirangiz — sizniki', 'Ваша память — только ваша', 'Your memory is yours'],
    'priv.v2': ['Bir marta ishonib topshirsangiz, boshqa hech qachon raqobatchiga oʻtmaysiz.', 'Один раз доверив память, вы уже не захотите уходить к конкурентам.', 'Trust it once and you will never want to switch.'],

    /* ---------- pricing ---------- */
    'price.title': ['Oddiy va ochiq narxlar', 'Простые и честные тарифы', 'Simple, honest pricing'],
    'price.sub': ['Bepul boshlang, kerak boʻlganda kengaytiring.', 'Начните бесплатно, расширяйтесь когда нужно.', 'Start free, grow when you need to.'],
    'price.mo': ['/oy', '/мес', '/mo'],
    'price.pop': ['Mashhur', 'Популярный', 'Popular'],
    'free.name': ['Bepul', 'Бесплатный', 'Free'],
    'free.desc': ['Shaxsiy foydalanish va sinab koʻrish uchun.', 'Для личного использования и знакомства.', 'For personal use and trying it out.'],
    'free.f1': ['100 tagacha hujjat', 'До 100 документов', 'Up to 100 documents'],
    'free.f2': ['Kuniga 20 ta savol', '20 вопросов в день', '20 questions per day'],
    'free.f3': ['Bilimlar grafi', 'Граф знаний', 'Knowledge graph'],
    'free.f4': ['3 til, JSON eksport', '3 языка, экспорт JSON', '3 languages, JSON export'],
    'pro.desc': ['Jiddiy foydalanuvchilar va mutaxassislar uchun.', 'Для профессионалов и активных пользователей.', 'For professionals and power users.'],
    'pro.f1': ['Cheksiz hujjatlar', 'Неограниченно документов', 'Unlimited documents'],
    'pro.f2': ['Cheksiz savollar', 'Неограниченно вопросов', 'Unlimited questions'],
    'pro.f3': ['PDF, SRT, VTT, havolalar', 'PDF, SRT, VTT, ссылки', 'PDF, SRT, VTT, links'],
    'pro.f4': ['Ustuvor yordam', 'Приоритетная поддержка', 'Priority support'],
    'corp.name': ['Korporativ', 'Корпоративный', 'Corporate'],
    'corp.price': ['Kelishuv asosida', 'По договорённости', 'Custom'],
    'corp.desc': ['Kompaniyalar va jamoalar uchun — suhbat orqali.', 'Для компаний и команд — через обсуждение.', 'For companies and teams — through a conversation.'],
    'corp.f1': ['Jamoaviy xotira', 'Командная память', 'Shared team memory'],
    'corp.f2': ['Oʻz serveringizda joylashtirish', 'Развёртывание на вашем сервере', 'Deploy on your own server'],
    'corp.f3': ['Integratsiyalar (Gmail, Drive, Telegram)', 'Интеграции (Gmail, Drive, Telegram)', 'Integrations (Gmail, Drive, Telegram)'],
    'corp.f4': ['Shaxsiy menejer', 'Персональный менеджер', 'Dedicated manager'],
    'plan.free': ['Bepul boshlash', 'Начать бесплатно', 'Start free'],
    'plan.pro': ['Pro tanlash', 'Выбрать Pro', 'Choose Pro'],
    'plan.corp': ['Telegram orqali yozish', 'Написать в Telegram', 'Message on Telegram'],
    'faq.title': ['Koʻp beriladigan savollar', 'Частые вопросы', 'Frequently asked questions'],
    'faq.q1': ['Maʼlumotlarim xavfsizmi?', 'Мои данные в безопасности?', 'Is my data safe?'],
    'faq.a1': ['Ha. Har bir foydalanuvchining xotirasi alohida, parollar shifrlangan (scrypt) holda saqlanadi. Istalgan payt eksport qilish yoki butunlay oʻchirish mumkin.', 'Да. Память каждого пользователя изолирована, пароли хранятся в виде хешей (scrypt). Данные можно экспортировать или полностью удалить в любой момент.', 'Yes. Every user’s memory is isolated and passwords are stored as scrypt hashes. You can export or fully delete your data at any time.'],
    'faq.q2': ['Qaysi fayllarni qoʻshish mumkin?', 'Какие файлы можно добавить?', 'What can I add?'],
    'faq.a2': ['Qaydlar, xatlar, uchrashuv transkriptlari, veb-havolalar, PDF, TXT, MD, CSV, JSON, SRT, VTT va HTML fayllar.', 'Заметки, письма, транскрипты встреч, веб-ссылки, PDF, TXT, MD, CSV, JSON, SRT, VTT и HTML.', 'Notes, emails, meeting transcripts, web links, PDF, TXT, MD, CSV, JSON, SRT, VTT and HTML files.'],
    'faq.q3': ['Qanday tillarda ishlaydi?', 'На каких языках работает?', 'Which languages does it support?'],
    'faq.a3': ['Interfeys va qidiruv oʻzbek, rus va ingliz tillarida ishlaydi. Hujjatlarni aralash tillarda ham qoʻshish mumkin.', 'Интерфейс и поиск работают на узбекском, русском и английском. Документы можно добавлять и на смешанных языках.', 'The interface and search work in Uzbek, Russian and English. Documents can be in mixed languages.'],
    'faq.q4': ['Pro uchun qanday toʻlanadi?', 'Как оплатить Pro?', 'How do I pay for Pro?'],
    'faq.a4': ['Payme orqali. Korporativ tarif uchun Telegram orqali yozing.', 'Через Payme. Для корпоративного тарифа напишите в Telegram.', 'Via Payme. For the Corporate plan, message us on Telegram.'],
    'final.title': ['Xotirangizni bugun boshlang', 'Начните свою память уже сегодня', 'Start your memory today'],
    'final.sub': ['Birinchi hujjatni qoʻshing va birinchi savolingizni bering.', 'Добавьте первый документ и задайте первый вопрос.', 'Add your first document and ask your first question.'],
    'foot.copy': ['© MemGraph — Shaxsiy va korporativ xotira bazasi', '© MemGraph — личная и корпоративная база памяти', '© MemGraph — personal & corporate memory infrastructure'],

    /* ---------- auth ---------- */
    'auth.tabLogin': ['Kirish', 'Вход', 'Log in'],
    'auth.tabReg': ['Roʻyxatdan oʻtish', 'Регистрация', 'Sign up'],
    'auth.loginTitle': ['Qaytib kelganingiz bilan!', 'С возвращением!', 'Welcome back!'],
    'auth.regTitle': ['Hisob yaratish', 'Создать аккаунт', 'Create your account'],
    'auth.loginLead': ['Xotirangizga kirish uchun hisobingizga kiring.', 'Войдите, чтобы открыть свою память.', 'Sign in to open your memory.'],
    'auth.regLead': ['Bepul hisob — kredit karta kerak emas.', 'Бесплатный аккаунт — карта не нужна.', 'Free account — no credit card needed.'],
    'auth.google': ['Google orqali davom etish', 'Продолжить через Google', 'Continue with Google'],
    'auth.or': ['yoki email bilan', 'или по email', 'or with email'],
    'auth.name': ['Ismingiz', 'Ваше имя', 'Your name'],
    'auth.email': ['Email', 'Email', 'Email'],
    'auth.password': ['Parol', 'Пароль', 'Password'],
    'auth.gen': ['Parol yaratish', 'Сгенерировать', 'Generate'],
    'auth.submitLogin': ['Kirish', 'Войти', 'Log in'],
    'auth.submitReg': ['Hisob yaratish', 'Создать аккаунт', 'Create account'],
    'auth.copied': ['Parol nusxalandi', 'Пароль скопирован', 'Password copied'],
    'auth.generated': ['Kuchli parol yaratildi — nusxalab saqlab qoʻying', 'Создан надёжный пароль — скопируйте и сохраните', 'Strong password generated — copy and save it'],
    'pw.hint': ['Kamida 8 ta belgi', 'Минимум 8 символов', 'At least 8 characters'],
    'pw.weak': ['Zaif parol', 'Слабый пароль', 'Weak password'],
    'pw.ok': ['Oʻrtacha parol', 'Средний пароль', 'Fair password'],
    'pw.strong': ['Kuchli parol', 'Надёжный пароль', 'Strong password'],
    'auth.googleOff': ['Google kirishi hali sozlanmagan: administrator .env faylida GOOGLE_CLIENT_ID ni kiritishi kerak (README.md ga qarang).', 'Вход через Google ещё не настроен: администратору нужно указать GOOGLE_CLIENT_ID в .env (см. README.md).', 'Google sign-in is not configured yet: the admin must set GOOGLE_CLIENT_ID in .env (see README.md).'],

    /* ---------- errors ---------- */
    'err.BAD_EMAIL': ['Email notoʻgʻri kiritilgan', 'Некорректный email', 'Invalid email address'],
    'err.WEAK_PASSWORD': ['Parol kamida 8 ta belgidan iborat boʻlishi kerak', 'Пароль должен быть не короче 8 символов', 'Password must be at least 8 characters'],
    'err.EMAIL_TAKEN': ['Bu email allaqachon roʻyxatdan oʻtgan', 'Этот email уже зарегистрирован', 'This email is already registered'],
    'err.BAD_CREDENTIALS': ['Email yoki parol notoʻgʻri', 'Неверный email или пароль', 'Wrong email or password'],
    'err.USE_GOOGLE': ['Bu hisob Google orqali yaratilgan — Google tugmasi bilan kiring', 'Этот аккаунт создан через Google — войдите кнопкой Google', 'This account was created with Google — use the Google button'],
    'err.GOOGLE_NOT_CONFIGURED': ['Google kirishi sozlanmagan', 'Вход через Google не настроен', 'Google sign-in is not configured'],
    'err.GOOGLE_FAILED': ['Google tasdiqlashdan oʻtmadi, qayta urinib koʻring', 'Google не подтвердил вход, попробуйте ещё раз', 'Google verification failed, please try again'],
    'err.RATE_LIMIT': ['Juda koʻp urinish. Birozdan soʻng qayta urinib koʻring', 'Слишком много попыток. Повторите позже', 'Too many attempts. Please try again later'],
    'err.UNAUTHORIZED': ['Sessiya tugadi, qaytadan kiring', 'Сессия истекла, войдите снова', 'Session expired, please log in again'],
    'err.EMPTY': ['Matn juda qisqa yoki boʻsh', 'Текст пустой или слишком короткий', 'The text is empty or too short'],
    'err.LIMIT_DOCS': ['Bepul tarif limiti (100 hujjat) tugadi. Pro ga oʻting', 'Лимит бесплатного тарифа (100 документов) исчерпан. Перейдите на Pro', 'Free plan limit (100 documents) reached. Upgrade to Pro'],
    'err.LIMIT_ASKS': ['Bugungi bepul savollar limiti tugadi. Pro ga oʻting', 'Дневной лимит бесплатных вопросов исчерпан. Перейдите на Pro', 'Daily free question limit reached. Upgrade to Pro'],
    'err.BAD_URL': ['Havola notoʻgʻri', 'Некорректная ссылка', 'Invalid link'],
    'err.FETCH_FAILED': ['Havolani ochib boʻlmadi', 'Не удалось открыть ссылку', 'Could not fetch the link'],
    'err.PDF_NOT_INSTALLED': ['PDF oʻqish oʻrnatilmagan: serverda "npm install" ni ishga tushiring', 'Чтение PDF не установлено: выполните "npm install" на сервере', 'PDF support not installed: run "npm install" on the server'],
    'err.PDF_UNREADABLE': ['PDF faylni oʻqib boʻlmadi (skaner qilingan boʻlishi mumkin)', 'Не удалось прочитать PDF (возможно, это скан)', 'Could not read the PDF (it may be a scan)'],
    'err.TOO_LARGE': ['Fayl juda katta (maks. ~18 MB)', 'Файл слишком большой (макс. ~18 МБ)', 'File too large (max ~18 MB)'],
    'err.SERVER_ERROR': ['Server xatosi, birozdan soʻng urinib koʻring', 'Ошибка сервера, попробуйте позже', 'Server error, please try again shortly'],
    'err.NETWORK': ['Tarmoq xatosi', 'Ошибка сети', 'Network error'],
    'err.CONFIRM_MISMATCH': ['Tasdiqlash emaili mos kelmadi', 'Email подтверждения не совпал', 'Confirmation email does not match'],
    'err.FORBIDDEN_ORIGIN': ['Soʻrov rad etildi', 'Запрос отклонён', 'Request rejected'],
    'err.BAD_JSON': ['Soʻrov formati notoʻgʻri', 'Неверный формат запроса', 'Malformed request'],
    'err.NOT_FOUND': ['Topilmadi', 'Не найдено', 'Not found'],
    'err.UNSUPPORTED': ['Bu fayl turi qoʻllab-quvvatlanmaydi', 'Этот тип файла не поддерживается', 'This file type is not supported'],

    /* ---------- dashboard ---------- */
    'home.askTitle': ['Xotirangizdan soʻrang', 'Спросите свою память', 'Ask your memory'],
    'home.askPh': ['Masalan: Oʻtgan oy moliya bilan nima kelishgan edik?', 'Например: что мы согласовали с финансами в прошлом месяце?', 'e.g. What did we agree with finance last month?'],
    'home.recent': ['Oxirgi qoʻshilganlar', 'Недавно добавлено', 'Recently added'],
    'home.usage': ['Foydalanish', 'Использование', 'Usage'],
    'home.noDocs': ['Hali hech narsa yoʻq. Birinchi yozuvni qoʻshing!', 'Пока ничего нет. Добавьте первую запись!', 'Nothing yet. Add your first entry!'],
    'home.addFirst': ['Xotira qoʻshish', 'Добавить в память', 'Add memory'],
    'kpi.docs': ['Hujjatlar', 'Документы', 'Documents'],
    'kpi.chunks': ['Xotira boʻlaklari', 'Фрагменты памяти', 'Memory chunks'],
    'kpi.entities': ['Graf tugunlari', 'Узлы графа', 'Graph nodes'],
    'kpi.asks': ['Savollar', 'Вопросы', 'Questions'],
    'usage.docs': ['Hujjatlar', 'Документы', 'Documents'],
    'usage.asks': ['Bugungi savollar', 'Вопросы сегодня', 'Questions today'],
    'usage.unlimited': ['cheksiz', 'без лимита', 'unlimited'],
    'type.note': ['Qayd', 'Заметка', 'Note'],
    'type.email': ['Xat', 'Письмо', 'Email'],
    'type.meeting': ['Uchrashuv', 'Встреча', 'Meeting'],
    'type.link': ['Havola', 'Ссылка', 'Link'],
    'type.pdf': ['PDF', 'PDF', 'PDF'],
    'type.file': ['Fayl', 'Файл', 'File'],
    'plan.name.free': ['Bepul', 'Бесплатный', 'Free'],
    'plan.name.pro': ['Pro', 'Pro', 'Pro'],
    'plan.name.corporate': ['Korporativ', 'Корпоративный', 'Corporate'],
    'plan.yours': ['Sizning tarifingiz', 'Ваш тариф', 'Your plan'],
    'plan.upgrade': ['Pro ga oʻtish — $12/oy', 'Перейти на Pro — $12/мес', 'Upgrade to Pro — $12/mo'],
    'plan.payme': ['Payme orqali toʻlash', 'Оплатить через Payme', 'Pay with Payme'],
    'plan.noPayme': ['Toʻlov havolasi hali sozlanmagan. Pro uchun Telegram orqali yozing.', 'Ссылка на оплату ещё не настроена. Для Pro напишите в Telegram.', 'The payment link is not configured yet. Message us on Telegram for Pro.'],
    'plan.corpBtn': ['Korporativ — Telegram', 'Корпоративный — Telegram', 'Corporate — Telegram'],
    'plan.activeInfo': ['Joriy tarif:', 'Текущий тариф:', 'Current plan:'],
    'ask.ph': ['Savolingizni yozing…', 'Введите вопрос…', 'Type your question…'],
    'ask.btn': ['Soʻrash', 'Спросить', 'Ask'],
    'ask.clear': ['Tarixni tozalash', 'Очистить историю', 'Clear history'],
    'ask.clearConfirm': ['Savol-javoblar tarixi oʻchirilsinmi?', 'Удалить историю вопросов и ответов?', 'Delete the question & answer history?'],
    'ask.sources': ['Manbalar', 'Источники', 'Sources'],
    'ask.mode.ai': ['AI javobi', 'Ответ ИИ', 'AI answer'],
    'ask.mode.local': ['Mahalliy qidiruv', 'Локальный поиск', 'Local search'],
    'ask.noHist': ['Hali savol berilmagan. Yuqoridagi maydonga yozing.', 'Вопросов пока нет. Введите вопрос выше.', 'No questions yet. Type one above.'],
    'ask.s1': ['Oxirgi kelishuvlar nima edi?', 'Какие были последние договорённости?', 'What were the latest agreements?'],
    'ask.s2': ['Byudjet haqida nima yozilgan?', 'Что написано про бюджет?', 'What is written about the budget?'],
    'ask.s3': ['Muddatlar qachon?', 'Какие сроки?', 'What are the deadlines?'],
    'add.note': ['Qayd', 'Заметка', 'Note'],
    'add.email': ['Xat', 'Письмо', 'Email'],
    'add.meeting': ['Uchrashuv', 'Встреча', 'Meeting'],
    'add.url': ['Havola', 'Ссылка', 'Link'],
    'add.file': ['Fayl / PDF', 'Файл / PDF', 'File / PDF'],
    'add.title': ['Sarlavha (ixtiyoriy)', 'Заголовок (необязательно)', 'Title (optional)'],
    'add.lbl.note': ['Qayd matni', 'Текст заметки', 'Note text'],
    'add.lbl.email': ['Xat matni (mavzu, kimdan, matn)', 'Текст письма (тема, от кого, текст)', 'Email text (subject, from, body)'],
    'add.lbl.meeting': ['Uchrashuv transkripti yoki xulosasi', 'Транскрипт или итоги встречи', 'Meeting transcript or summary'],
    'add.urlLbl': ['Maqola yoki sahifa havolasi', 'Ссылка на статью или страницу', 'Article or page link'],
    'add.drop': ['Faylni shu yerga tashlang yoki bosing', 'Перетащите файл сюда или нажмите', 'Drop files here or click'],
    'add.types': ['PDF, TXT, MD, CSV, JSON, SRT, VTT, HTML, EML', 'PDF, TXT, MD, CSV, JSON, SRT, VTT, HTML, EML', 'PDF, TXT, MD, CSV, JSON, SRT, VTT, HTML, EML'],
    'add.save': ['Xotiraga saqlash', 'Сохранить в память', 'Save to memory'],
    'add.saving': ['Saqlanmoqda…', 'Сохраняется…', 'Saving…'],
    'add.saved': ['Saqlandi', 'Сохранено', 'Saved'],
    'add.savedDetail': ['boʻlak, graf tuguni', 'фрагм., узлов графа', 'chunks, graph nodes'],
    'add.noFile': ['Avval fayl tanlang', 'Сначала выберите файл', 'Choose a file first'],
    'lib.ph': ['Kutubxonadan qidirish…', 'Поиск по библиотеке…', 'Search the library…'],
    'lib.all': ['Hammasi', 'Все', 'All'],
    'lib.empty': ['Hech narsa topilmadi', 'Ничего не найдено', 'Nothing found'],
    'lib.delete': ['Oʻchirish', 'Удалить', 'Delete'],
    'lib.confirmDel': ['Bu hujjat xotiradan oʻchirilsinmi?', 'Удалить этот документ из памяти?', 'Delete this document from memory?'],
    'lib.deleted': ['Oʻchirildi', 'Удалено', 'Deleted'],
    'lib.related': ['Bogʻliq tushunchalar', 'Связанные понятия', 'Related concepts'],
    'graph.title': ['Bilimlar grafi', 'Граф знаний', 'Knowledge graph'],
    'graph.hint': ['Tugunni sudrang, hujjat ustiga bosing — ochiladi. Bir nechta hujjatda uchraydigan shaxs va mavzular bogʻlanib turadi.', 'Перетаскивайте узлы, нажмите на документ — он откроется. Люди и темы, встречающиеся в нескольких документах, связываются.', 'Drag nodes, click a document to open it. People and topics that appear in several documents get linked.'],
    'graph.doc': ['Hujjat', 'Документ', 'Document'],
    'graph.entity': ['Shaxs / tashkilot', 'Человек / организация', 'Person / organization'],
    'graph.topic': ['Mavzu', 'Тема', 'Topic'],
    'graph.empty': ['Graf boʻsh. Kamida 2 ta hujjat qoʻshing.', 'Граф пуст. Добавьте хотя бы 2 документа.', 'The graph is empty. Add at least 2 documents.'],
    'set.profile': ['Profil', 'Профиль', 'Profile'],
    'set.save': ['Saqlash', 'Сохранить', 'Save'],
    'set.saved': ['Saqlandi', 'Сохранено', 'Saved'],
    'set.plan': ['Tarif', 'Тариф', 'Plan'],
    'set.data': ['Maʼlumotlar', 'Данные', 'Data'],
    'set.dataD': ['Barcha hujjat va savollaringizni JSON fayl sifatida yuklab oling.', 'Скачайте все документы и вопросы одним JSON-файлом.', 'Download all your documents and questions as a JSON file.'],
    'set.export': ['JSON yuklab olish', 'Скачать JSON', 'Download JSON'],
    'set.danger': ['Xavfli hudud', 'Опасная зона', 'Danger zone'],
    'set.dangerD': ['Hisob va barcha xotira butunlay oʻchiriladi. Tasdiqlash uchun emailingizni kiriting.', 'Аккаунт и вся память будут удалены безвозвратно. Для подтверждения введите ваш email.', 'Your account and all memory will be permanently deleted. Type your email to confirm.'],
    'set.typeEmail': ['Emailingizni kiriting', 'Введите ваш email', 'Type your email'],
    'set.delete': ['Hisobni oʻchirish', 'Удалить аккаунт', 'Delete account'],
  };

  const LANGS = ['uz', 'ru', 'en'];
  const IDX = { uz: 0, ru: 1, en: 2 };
  let lang = 'uz';
  try {
    const s = localStorage.getItem('mg_lang');
    if (LANGS.includes(s)) lang = s;
    else {
      const n = (navigator.language || 'uz').slice(0, 2).toLowerCase();
      lang = n === 'ru' ? 'ru' : n === 'en' ? 'en' : 'uz';
    }
  } catch (_) {}

  function t(k) {
    const e = D[k];
    return e ? e[IDX[lang]] : k;
  }

  function apply(root) {
    root = root || document;
    document.documentElement.lang = lang;
    root.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
    root.querySelectorAll('[data-i18n-html]').forEach((el) => { el.innerHTML = t(el.dataset.i18nHtml); });
    root.querySelectorAll('[data-i18n-ph]').forEach((el) => { el.placeholder = t(el.dataset.i18nPh); });
    document.querySelectorAll('[data-lang-switch]').forEach((box) => {
      box.innerHTML = LANGS.map((l) => '<button type="button" data-l="' + l + '" class="' + (l === lang ? 'on' : '') + '">' + l.toUpperCase() + '</button>').join('');
    });
  }

  function setLang(l) {
    if (!LANGS.includes(l) || l === lang) return;
    lang = l;
    try { localStorage.setItem('mg_lang', l); } catch (_) {}
    apply();
    window.dispatchEvent(new CustomEvent('langchange', { detail: l }));
  }

  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-lang-switch] button');
    if (b) setLang(b.dataset.l);
  });

  window.I18N = { t, apply, setLang, lang: () => lang, dict: D };
  document.addEventListener('DOMContentLoaded', () => apply());
})();
