(function () {
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const t = (k) => I18N.t(k);
  let cfg = { googleClientId: '' };
  let mode = 'register';
  let loggedIn = false;
  let gsiReady = false;

  function toast(msg, isErr) {
    const el = $('#toast');
    el.textContent = msg;
    el.className = 'toast show' + (isErr ? ' err' : '');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => { el.className = 'toast'; }, 3200);
  }

  async function api(path, opts) {
    try {
      const r = await fetch(path, Object.assign({ headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin' }, opts));
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw Object.assign(new Error(j.error || 'SERVER_ERROR'), { code: j.error || 'SERVER_ERROR' });
      return j;
    } catch (e) {
      if (e.code) throw e;
      throw Object.assign(new Error('NETWORK'), { code: 'NETWORK' });
    }
  }
  const errText = (code) => { const k = 'err.' + code; const v = t(k); return v === k ? t('err.SERVER_ERROR') : v; };

  /* ---------- modal ---------- */
  function showMsg(text, kind) {
    $('#authMsg').innerHTML = text ? '<div class="msg ' + (kind || 'err') + '"></div>' : '';
    if (text) $('#authMsg .msg').textContent = text;
  }

  function renderMode() {
    const reg = mode === 'register';
    $('#authTitle').textContent = t(reg ? 'auth.regTitle' : 'auth.loginTitle');
    $('#authLead').textContent = t(reg ? 'auth.regLead' : 'auth.loginLead');
    $('#authSubmit').textContent = t(reg ? 'auth.submitReg' : 'auth.submitLogin');
    $('#nameField').classList.toggle('hidden', !reg);
    $('#pwGen').classList.toggle('hidden', !reg);
    $('#pwInp').autocomplete = reg ? 'new-password' : 'current-password';
    $$('.tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === mode));
    updateStrength();
    showMsg('');
  }

  function openAuth(m) {
    mode = m;
    $('#authOv').classList.add('open');
    renderMode();
    renderGoogle();
    setTimeout(() => { const f = m === 'register' ? $('[name=name]') : $('[name=email]'); if (f) f.focus(); }, 50);
  }
  function closeAuth() { $('#authOv').classList.remove('open'); }

  document.addEventListener('click', (e) => {
    const o = e.target.closest('[data-open]');
    if (o) { e.preventDefault(); if (loggedIn) location.href = '/app'; else openAuth(o.dataset.open); return; }
    const tab = e.target.closest('.tabs button');
    if (tab) { mode = tab.dataset.tab; renderMode(); return; }
    if (e.target.closest('[data-close]') || e.target.id === 'authOv') closeAuth();
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeAuth(); });
  $('#navLogin').addEventListener('click', () => openAuth('login'));
  $('#navSignup').addEventListener('click', () => { if (loggedIn) location.href = '/app'; else openAuth('register'); });

  /* ---------- password generator + strength ---------- */
  function genPassword(len) {
    len = len || 16;
    const sets = ['abcdefghijkmnpqrstuvwxyz', 'ABCDEFGHJKLMNPQRSTUVWXYZ', '23456789', '!@#$%^&*-_=+?'];
    const all = sets.join('');
    const rnd = (n) => { const a = new Uint32Array(1); const lim = Math.floor(0x100000000 / n) * n; let x; do { crypto.getRandomValues(a); x = a[0]; } while (x >= lim); return x % n; };
    const out = sets.map((s) => s[rnd(s.length)]);
    while (out.length < len) out.push(all[rnd(all.length)]);
    for (let i = out.length - 1; i > 0; i--) { const j = rnd(i + 1); [out[i], out[j]] = [out[j], out[i]]; }
    return out.join('');
  }

  function strength(p) {
    let s = 0;
    if (p.length >= 8) s++;
    if (p.length >= 12) s++;
    if (/[a-z]/.test(p) && /[A-Z]/.test(p)) s++;
    if (/\d/.test(p)) s++;
    if (/[^A-Za-z0-9]/.test(p)) s++;
    return Math.min(4, Math.max(p ? 1 : 0, s - (p.length < 8 ? 1 : 0)));
  }
  function updateStrength() {
    const p = $('#pwInp').value;
    const s = strength(p);
    const bar = $('#pwBar');
    bar.style.width = (p ? Math.max(12, s * 25) : 0) + '%';
    bar.style.background = s <= 1 ? '#C4513F' : s <= 2 ? '#D9A441' : '#2F6B4F';
    $('#pwHint').textContent = !p || mode === 'login' ? (mode === 'register' ? t('pw.hint') : '') : (s <= 1 ? t('pw.weak') : s <= 2 ? t('pw.ok') : t('pw.strong'));
  }
  $('#pwInp').addEventListener('input', updateStrength);
  $('#pwGen').addEventListener('click', async () => {
    const p = genPassword(16);
    const inp = $('#pwInp');
    inp.value = p; inp.type = 'text';
    updateStrength();
    try { await navigator.clipboard.writeText(p); } catch (_) {}
    showMsg(t('auth.generated'), 'ok');
  });
  $('#pwEye').addEventListener('click', () => { const i = $('#pwInp'); i.type = i.type === 'password' ? 'text' : 'password'; });
  $('#pwCopy').addEventListener('click', async () => {
    const v = $('#pwInp').value; if (!v) return;
    try { await navigator.clipboard.writeText(v); toast(t('auth.copied')); } catch (_) { $('#pwInp').select(); }
  });

  /* ---------- email auth ---------- */
  $('#authForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    const reg = mode === 'register';
    const btn = $('#authSubmit');
    btn.disabled = true; showMsg('');
    try {
      await api('/api/auth/' + (reg ? 'register' : 'login'), {
        method: 'POST',
        body: JSON.stringify({ name: f.name.value, email: f.email.value, password: f.password.value, lang: I18N.lang() }),
      });
      location.href = '/app';
    } catch (err) { showMsg(errText(err.code)); btn.disabled = false; }
  });

  /* ---------- Google sign-in (Google Identity Services) ---------- */
  function loadGsi() {
    return new Promise((res, rej) => {
      if (window.google && google.accounts && google.accounts.id) return res();
      const s = document.createElement('script');
      s.src = 'https://accounts.google.com/gsi/client'; s.async = true; s.defer = true;
      s.onload = () => res(); s.onerror = () => rej(new Error('gsi'));
      document.head.appendChild(s);
    });
  }

  async function onGoogleCredential(resp) {
    showMsg('');
    try {
      await api('/api/auth/google', { method: 'POST', body: JSON.stringify({ credential: resp.credential, lang: I18N.lang() }) });
      location.href = '/app';
    } catch (err) { showMsg(errText(err.code)); }
  }

  function fallbackGoogle(slot, message) {
    slot.innerHTML = '<button type="button" class="gbtn">' + GOOGLE_G + '<span></span></button>';
    $('span', slot).textContent = t('auth.google');
    $('button', slot).addEventListener('click', () => showMsg(message || t('auth.googleOff')));
  }

  async function renderGoogle() {
    const slot = $('#gslot');
    if (!cfg.googleClientId) return fallbackGoogle(slot);
    try {
      await loadGsi();
      if (!gsiReady) {
        google.accounts.id.initialize({ client_id: cfg.googleClientId, callback: onGoogleCredential, ux_mode: 'popup', auto_select: false });
        gsiReady = true;
      }
      slot.innerHTML = '';
      const w = Math.min(384, Math.max(240, slot.clientWidth || 384));
      google.accounts.id.renderButton(slot, {
        type: 'standard', theme: 'outline', size: 'large', shape: 'pill', logo_alignment: 'left', width: w,
        text: mode === 'register' ? 'signup_with' : 'signin_with', locale: I18N.lang(),
      });
    } catch (_) { fallbackGoogle(slot, t('err.NETWORK')); }
  }

  window.addEventListener('langchange', () => {
    if ($('#authOv').classList.contains('open')) { renderMode(); renderGoogle(); }
    setNav();
  });

  function setNav() {
    $('#navLogin').classList.toggle('hidden', loggedIn);
    $('#navSignup').textContent = t(loggedIn ? 'nav.open' : 'nav.signup');
  }

  /* ---------- boot ---------- */
  (async function boot() {
    try { cfg = await api('/api/config'); } catch (_) {}
    if (cfg.telegramUrl) $('#corpBtn').href = cfg.telegramUrl;
    try { await api('/api/me'); loggedIn = true; } catch (_) {}
    IC.hydrate();
    setNav();
    if (location.hash === '#login') openAuth('login');
    if (location.hash === '#signup') openAuth('register');
  })();
  document.addEventListener('DOMContentLoaded', () => { IC.hydrate(); setNav(); });
})();
