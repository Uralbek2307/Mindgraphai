(function () {
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const t = (k) => I18N.t(k);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const TYPE_IC = { note: ['note', 'green'], email: ['mail', 'blue'], meeting: ['mic', 'purple'], link: ['link', 'teal'], pdf: ['file', 'red'], file: ['file', 'amber'] };
  const LOCALE = { uz: 'uz-UZ', ru: 'ru-RU', en: 'en-GB' };

  let me = null, cfg = {}, stats = null, view = 'home', addKind = 'note', openDocId = null;
  let libDocs = [], libFilter = 'all', libTimer = null, files = [];

  /* ---------- helpers ---------- */
  function toast(msg, isErr) {
    const el = $('#toast');
    el.textContent = msg;
    el.className = 'toast show' + (isErr ? ' err' : '');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => { el.className = 'toast'; }, 3400);
  }
  async function api(path, opts) {
    let r;
    try { r = await fetch(path, Object.assign({ headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin' }, opts)); }
    catch (_) { throw Object.assign(new Error('NETWORK'), { code: 'NETWORK' }); }
    const j = await r.json().catch(() => ({}));
    if (r.status === 401) { location.href = '/'; throw Object.assign(new Error('UNAUTHORIZED'), { code: 'UNAUTHORIZED' }); }
    if (!r.ok) throw Object.assign(new Error(j.error || 'SERVER_ERROR'), { code: j.error || 'SERVER_ERROR', detail: j.detail });
    return j;
  }
  const errText = (c) => { const k = 'err.' + c; const v = t(k); return v === k ? t('err.SERVER_ERROR') : v; };
  const fail = (e) => toast(errText(e.code), true);
  const fmtDate = (ms) => new Date(ms).toLocaleDateString(LOCALE[I18N.lang()], { day: 'numeric', month: 'short', year: 'numeric' });
  const sticker = (name, color, size) => IC.sticker(name, color, size);
  const typeSticker = (type, size) => { const [n, c] = TYPE_IC[type] || TYPE_IC.file; return sticker(n, c, size || 'sm'); };

  /* ---------- navigation ---------- */
  function go(v) {
    view = v;
    $$('.view').forEach((el) => el.classList.toggle('on', el.id === 'v-' + v));
    $$('.nv[data-view]').forEach((b) => b.classList.toggle('on', b.dataset.view === v));
    $('#viewTitle').textContent = t('nav.' + v);
    $('#side').classList.remove('open');
    if (v === 'home') renderHome();
    if (v === 'ask') loadHistory();
    if (v === 'add') renderAddMode();
    if (v === 'library') loadLibrary();
    if (v === 'graph') loadGraph();
    if (v === 'settings') renderSettings();
    window.scrollTo(0, 0);
    try { history.replaceState(null, '', '#' + v); } catch (_) {}
  }
  document.addEventListener('click', (e) => {
    const nv = e.target.closest('.nv[data-view]');
    if (nv) go(nv.dataset.view);
    if (e.target.closest('[data-close]') || e.target.classList.contains('overlay')) $('#docOv').classList.remove('open');
  });
  $('#burger').addEventListener('click', () => $('#side').classList.toggle('open'));
  $('#logout').addEventListener('click', async () => { try { await api('/api/auth/logout', { method: 'POST' }); } catch (_) {} location.href = '/'; });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') $('#docOv').classList.remove('open'); });

  /* ---------- user / plan ---------- */
  function renderUser() {
    $('#uName').textContent = me.name || me.email;
    $('#uMail').textContent = me.email;
    const av = $('#uAvatar');
    av.textContent = '';
    if (me.picture) { const img = document.createElement('img'); img.src = me.picture; img.alt = ''; img.referrerPolicy = 'no-referrer'; img.onerror = () => { av.textContent = (me.name || me.email)[0].toUpperCase(); }; av.appendChild(img); }
    else av.textContent = (me.name || me.email)[0].toUpperCase();
    const pc = $('#planCard');
    pc.innerHTML = '<small>' + esc(t('plan.yours')) + '</small><b>' + esc(t('plan.name.' + me.plan)) + '</b>';
    if (me.plan === 'free') {
      const b = document.createElement('button');
      b.className = 'btn sm'; b.textContent = t('plan.upgrade');
      b.addEventListener('click', () => go('settings'));
      pc.appendChild(b);
    }
  }

  async function refreshStats() { stats = await api('/api/stats'); return stats; }

  /* ---------- home ---------- */
  async function renderHome() {
    try { await refreshStats(); } catch (e) { return fail(e); }
    const k = [
      ['kpi.docs', stats.docs, 'library', 'green'], ['kpi.chunks', stats.chunks, 'brain', 'amber'],
      ['kpi.entities', stats.entities, 'graph', 'purple'], ['kpi.asks', stats.asks, 'chat', 'blue'],
    ];
    $('#kpis').innerHTML = k.map(([l, n, ic, c]) => '<div class="kpi">' + sticker(ic, c) + '<div><b>' + n + '</b><span>' + esc(t(l)) + '</span></div></div>').join('');

    const meter = (label, used, max) => {
      const pct = max == null ? 8 : Math.min(100, Math.round((used / max) * 100));
      return '<div><div class="row" style="justify-content:space-between"><b>' + esc(label) + '</b><span class="hint">' + used + ' / ' + (max == null ? esc(t('usage.unlimited')) : max) + '</span></div><div class="meter"><i style="width:' + pct + '%"></i></div></div>';
    };
    $('#usage').innerHTML = meter(t('usage.docs'), stats.docs, stats.limits.docs) + meter(t('usage.asks'), stats.asksToday, stats.limits.asksPerDay);

    try {
      const { docs } = await api('/api/docs');
      const box = $('#recent');
      if (!docs.length) {
        box.innerHTML = '<div class="empty">' + sticker('plus', 'amber', 'lg') + '<p>' + esc(t('home.noDocs')) + '</p><p style="margin-top:12px"><button class="btn sm" id="firstAdd">' + esc(t('home.addFirst')) + '</button></p></div>';
        $('#firstAdd').addEventListener('click', () => go('add'));
      } else {
        box.innerHTML = docs.slice(0, 6).map(docItem).join('');
        bindDocItems(box);
      }
    } catch (e) { fail(e); }
  }

  function docItem(d) {
    return '<div class="item" data-doc="' + d.id + '">' + typeSticker(d.type) + '<div class="mid"><div class="t">' + esc(d.title) + '</div><div class="s">' + esc((d.snippet || '').replace(/\s+/g, ' ')) + '</div></div><div class="d">' + esc(fmtDate(d.created_at)) + '</div></div>';
  }
  function bindDocItems(box) { $$('.item[data-doc]', box).forEach((el) => el.addEventListener('click', () => openDoc(+el.dataset.doc))); }

  $('#quickAsk').addEventListener('submit', (e) => {
    e.preventDefault();
    const q = $('#quickQ').value.trim();
    if (q.length < 2) return;
    $('#quickQ').value = '';
    go('ask');
    runAsk(q);
  });

  /* ---------- ask ---------- */
  function renderAnswerBlock(q, a) {
    const srcs = (a.sources || []).map((s) =>
      '<div class="src" data-doc="' + s.doc_id + '"><b>[' + s.n + '] ' + esc(s.title) + '</b><div>' + esc(s.snippet) + '…</div></div>').join('');
    return '<div class="bubq">' + esc(q) + '</div><div class="bubx"><div class="txt">' + esc(a.answer) + '</div>' +
      '<div class="meta"><span class="chip">' + esc(t(a.mode === 'ai' ? 'ask.mode.ai' : 'ask.mode.local')) + '</span>' +
      (a.ms != null ? '<span>⚡ ' + (a.ms < 1000 ? a.ms + ' ms' : (a.ms / 1000).toFixed(1) + ' s') + '</span>' : '') + '</div>' +
      (srcs ? '<div class="srcs">' + srcs + '</div>' : '') + '</div>';
  }
  function bindSources(box) { $$('.src[data-doc]', box).forEach((el) => el.addEventListener('click', () => openDoc(+el.dataset.doc))); }

  async function loadHistory() {
    $('#askSamples').innerHTML = ['ask.s1', 'ask.s2', 'ask.s3'].map((k) => '<button type="button" class="fbtn" data-q="' + k + '">' + esc(t(k)) + '</button>').join('');
    try {
      const { chats } = await api('/api/history');
      const chat = $('#chat');
      if (!chats.length) { chat.innerHTML = '<div class="empty">' + sticker('chat', 'blue', 'lg') + '<p>' + esc(t('ask.noHist')) + '</p></div>'; return; }
      chat.innerHTML = chats.slice().reverse().map((c) => '<div class="chat-item" style="display:grid;gap:10px">' + renderAnswerBlock(c.question, { answer: c.answer, sources: c.sources, mode: c.mode }) + '</div>').join('');
      bindSources(chat);
      setTimeout(() => window.scrollTo(0, document.body.scrollHeight), 30);
    } catch (e) { fail(e); }
  }
  $('#askSamples').addEventListener('click', (e) => { const b = e.target.closest('[data-q]'); if (b) { $('#askQ').value = t(b.dataset.q); $('#askQ').focus(); } });

  let asking = false;
  async function runAsk(q) {
    if (asking) return;
    asking = true;
    $('#askBtn').disabled = true;
    const chat = $('#chat');
    if (chat.querySelector('.empty')) chat.innerHTML = '';
    const wrap = document.createElement('div');
    wrap.style.cssText = 'display:grid;gap:10px';
    wrap.innerHTML = '<div class="bubq">' + esc(q) + '</div><div class="bubx"><div class="dots"><span></span><span></span><span></span></div></div>';
    chat.appendChild(wrap);
    wrap.scrollIntoView({ behavior: 'smooth', block: 'end' });
    try {
      const a = await api('/api/ask', { method: 'POST', body: JSON.stringify({ question: q, lang: I18N.lang() }) });
      wrap.innerHTML = renderAnswerBlock(q, a);
      bindSources(wrap);
      wrap.scrollIntoView({ behavior: 'smooth', block: 'end' });
    } catch (e) { wrap.remove(); fail(e); }
    asking = false;
    $('#askBtn').disabled = false;
  }
  $('#askForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const q = $('#askQ').value.trim();
    if (q.length < 2) return;
    $('#askQ').value = '';
    runAsk(q);
  });
  $('#clearHist').addEventListener('click', async () => {
    if (!confirm(t('ask.clearConfirm'))) return;
    try { await api('/api/history', { method: 'DELETE' }); loadHistory(); } catch (e) { fail(e); }
  });

  /* ---------- add memory ---------- */
  function renderAddMode() {
    $$('#addTabs button').forEach((b) => b.classList.toggle('on', b.dataset.k === addKind));
    const isUrl = addKind === 'url', isFile = addKind === 'file';
    $('#fText').classList.toggle('hidden', isUrl || isFile);
    $('#fUrl').classList.toggle('hidden', !isUrl);
    $('#fFile').classList.toggle('hidden', !isFile);
    $('#fTitle').classList.toggle('hidden', isFile && files.length > 1);
    if (!isUrl && !isFile) $('#lText').textContent = t('add.lbl.' + addKind);
  }
  $('#addTabs').addEventListener('click', (e) => { const b = e.target.closest('button[data-k]'); if (b) { addKind = b.dataset.k; renderAddMode(); } });

  const drop = $('#drop'), fileInp = $('#fileInp');
  drop.addEventListener('click', () => fileInp.click());
  ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', (e) => setFiles(e.dataTransfer.files));
  fileInp.addEventListener('change', () => setFiles(fileInp.files));
  function setFiles(list) {
    files = Array.from(list || []);
    $('#fileName').textContent = files.map((f) => f.name + ' (' + Math.ceil(f.size / 1024) + ' KB)').join(', ');
    renderAddMode();
  }

  const readText = (f) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result)); r.onerror = rej; r.readAsText(f); });
  const readB64 = (f) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1] || ''); r.onerror = rej; r.readAsDataURL(f); });

  $('#addForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = $('#addBtn');
    btn.disabled = true;
    const label = $('span', btn);
    label.textContent = t('add.saving');
    try {
      const title = $('#addTitle').value.trim();
      let results = [];
      if (addKind === 'url') {
        results.push(await api('/api/docs', { method: 'POST', body: JSON.stringify({ type: 'url', url: $('#addUrl').value.trim(), title }) }));
        $('#addUrl').value = '';
      } else if (addKind === 'file') {
        if (!files.length) throw Object.assign(new Error('x'), { code: 'NOFILE' });
        for (const f of files) {
          const ext = (f.name.split('.').pop() || '').toLowerCase();
          if (!['txt', 'md', 'csv', 'json', 'srt', 'vtt', 'html', 'htm', 'pdf', 'eml', 'log'].includes(ext)) throw Object.assign(new Error('x'), { code: 'UNSUPPORTED' });
          const body = ext === 'pdf' ? { type: 'file', filename: f.name, base64: await readB64(f) } : { type: 'file', filename: f.name, content: await readText(f) };
          if (title && files.length === 1) body.title = title;
          results.push(await api('/api/docs', { method: 'POST', body: JSON.stringify(body) }));
        }
        files = []; fileInp.value = ''; $('#fileName').textContent = '';
      } else {
        results.push(await api('/api/docs', { method: 'POST', body: JSON.stringify({ type: 'text', kind: addKind, title, content: $('#addText').value }) }));
        $('#addText').value = '';
      }
      $('#addTitle').value = '';
      const ch = results.reduce((a, r) => a + r.chunks, 0), en = results.reduce((a, r) => a + r.entities, 0);
      toast('✓ ' + t('add.saved') + ' — ' + ch + ' ' + t('add.savedDetail').split(',')[0] + ', ' + en + ' ' + t('add.savedDetail').split(',')[1].trim());
      renderAddMode();
    } catch (err) {
      if (err.code === 'NOFILE') toast(t('add.noFile'), true);
      else if (err.code === 'FETCH_FAILED' && err.detail) toast(errText('FETCH_FAILED') + ' (' + err.detail + ')', true);
      else fail(err);
    }
    btn.disabled = false;
    label.textContent = t('add.save');
  });

  /* ---------- library ---------- */
  async function loadLibrary() {
    const q = $('#libQ').value.trim();
    try {
      const { docs } = await api('/api/docs' + (q ? '?q=' + encodeURIComponent(q) : ''));
      libDocs = docs;
      renderLibrary();
    } catch (e) { fail(e); }
  }
  function renderLibrary() {
    const types = ['all', ...new Set(libDocs.map((d) => d.type))];
    if (!types.includes(libFilter)) libFilter = 'all';
    $('#libFilters').innerHTML = types.map((k) => '<button class="fbtn ' + (k === libFilter ? 'on' : '') + '" data-f="' + k + '">' + esc(k === 'all' ? t('lib.all') : t('type.' + k)) + '</button>').join('');
    const list = libDocs.filter((d) => libFilter === 'all' || d.type === libFilter);
    const box = $('#libList');
    box.innerHTML = list.length ? list.map(docItem).join('') : '<div class="empty">' + sticker('search', 'green', 'lg') + '<p>' + esc(t('lib.empty')) + '</p></div>';
    bindDocItems(box);
  }
  $('#libFilters').addEventListener('click', (e) => { const b = e.target.closest('[data-f]'); if (b) { libFilter = b.dataset.f; renderLibrary(); } });
  $('#libQ').addEventListener('input', () => { clearTimeout(libTimer); libTimer = setTimeout(loadLibrary, 250); });

  async function openDoc(id) {
    try {
      const { doc, entities } = await api('/api/docs/' + id);
      openDocId = id;
      $('#docTitle').textContent = doc.title;
      $('#docMeta').textContent = t('type.' + doc.type) + ' · ' + fmtDate(doc.created_at) + (doc.source ? ' · ' + doc.source : '');
      $('#docBody').textContent = doc.content;
      $('#docTags').innerHTML = entities.length ? entities.map((en) => '<span class="chip">' + esc(en.name) + '</span>').join('') : '';
      $('#docOv').classList.add('open');
    } catch (e) { fail(e); }
  }
  $('#docDel').addEventListener('click', async () => {
    if (!openDocId || !confirm(t('lib.confirmDel'))) return;
    try {
      await api('/api/docs/' + openDocId, { method: 'DELETE' });
      $('#docOv').classList.remove('open');
      toast(t('lib.deleted'));
      go(view);
    } catch (e) { fail(e); }
  });

  /* ---------- knowledge graph (canvas force layout) ---------- */
  const G = { nodes: [], edges: [], raf: 0, alpha: 1, drag: null, hover: null, moved: false, w: 0, h: 0, dpr: 1, empty: false };
  const KCOL = { doc: '#2F6B4F', entity: '#D9A441', email: '#3B7BC8', topic: '#8A63D2' };
  const canvas = $('#gcanvas'), ctx = canvas.getContext('2d');

  function sizeCanvas() {
    const r = canvas.getBoundingClientRect();
    G.dpr = window.devicePixelRatio || 1; G.w = r.width; G.h = r.height;
    canvas.width = r.width * G.dpr; canvas.height = r.height * G.dpr;
  }
  async function loadGraph() {
    sizeCanvas();
    try {
      const g = await api('/api/graph');
      const byId = new Map();
      G.nodes = g.nodes.map((n, i) => {
        const a = (i / Math.max(1, g.nodes.length)) * Math.PI * 2, rad = 60 + Math.random() * 120;
        const o = Object.assign({}, n, { x: G.w / 2 + Math.cos(a) * rad, y: G.h / 2 + Math.sin(a) * rad, vx: 0, vy: 0, r: n.kind === 'doc' ? 10 : 5 + Math.min(8, (n.count || 1)) });
        byId.set(n.id, o); return o;
      });
      G.edges = g.edges.map((e) => ({ a: byId.get(e.a), b: byId.get(e.b), t: e.t, w: e.w })).filter((e) => e.a && e.b);
      G.empty = G.nodes.length < 2;
      G.alpha = 1;
      cancelAnimationFrame(G.raf);
      tick();
    } catch (e) { fail(e); }
  }
  function step() {
    const n = G.nodes, a = G.alpha;
    for (let i = 0; i < n.length; i++) for (let j = i + 1; j < n.length; j++) {
      let dx = n[j].x - n[i].x, dy = n[j].y - n[i].y, d2 = dx * dx + dy * dy || 0.01;
      if (d2 > 250000) continue;
      const f = (5200 / d2) * a, d = Math.sqrt(d2);
      dx = (dx / d) * f; dy = (dy / d) * f;
      n[i].vx -= dx; n[i].vy -= dy; n[j].vx += dx; n[j].vy += dy;
    }
    for (const e of G.edges) {
      const dx = e.b.x - e.a.x, dy = e.b.y - e.a.y, d = Math.sqrt(dx * dx + dy * dy) || 1;
      const len = e.t === 'sim' ? 190 : 120, f = (d - len) * 0.02 * a;
      const fx = (dx / d) * f, fy = (dy / d) * f;
      e.a.vx += fx; e.a.vy += fy; e.b.vx -= fx; e.b.vy -= fy;
    }
    for (const p of n) {
      p.vx += (G.w / 2 - p.x) * 0.0025 * a; p.vy += (G.h / 2 - p.y) * 0.0025 * a;
      if (p === G.drag) { p.vx = 0; p.vy = 0; continue; }
      p.vx *= 0.82; p.vy *= 0.82;
      p.x = Math.max(p.r, Math.min(G.w - p.r, p.x + p.vx)); p.y = Math.max(p.r, Math.min(G.h - p.r, p.y + p.vy));
    }
    G.alpha = Math.max(0.02, G.alpha * 0.985);
  }
  function draw() {
    ctx.setTransform(G.dpr, 0, 0, G.dpr, 0, 0);
    ctx.clearRect(0, 0, G.w, G.h);
    if (G.empty) {
      ctx.fillStyle = '#68746B'; ctx.font = '16px sans-serif'; ctx.textAlign = 'center';
      ctx.fillText(t('graph.empty'), G.w / 2, G.h / 2); return;
    }
    for (const e of G.edges) {
      ctx.beginPath(); ctx.moveTo(e.a.x, e.a.y); ctx.lineTo(e.b.x, e.b.y);
      ctx.strokeStyle = e.t === 'sim' ? 'rgba(47,107,79,.35)' : 'rgba(104,116,107,.32)';
      ctx.lineWidth = e.t === 'sim' ? 1.8 : 1; ctx.setLineDash(e.t === 'sim' ? [5, 4] : []); ctx.stroke();
    }
    ctx.setLineDash([]);
    ctx.textAlign = 'center'; ctx.font = '12px -apple-system,Segoe UI,sans-serif';
    for (const p of G.nodes) {
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r + (p === G.hover ? 2 : 0), 0, Math.PI * 2);
      ctx.fillStyle = KCOL[p.kind] || KCOL.entity; ctx.fill();
      ctx.lineWidth = 2.5; ctx.strokeStyle = '#fff'; ctx.stroke();
    }
    for (const p of G.nodes) {
      if (p.kind !== 'doc' && p !== G.hover && !(p.count >= 3)) continue;
      const label = p === G.hover ? p.label : (p.label.length > 24 ? p.label.slice(0, 23) + '…' : p.label);
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(255,252,243,.95)'; ctx.strokeText(label, p.x, p.y - p.r - 6);
      ctx.fillStyle = '#1E2A22'; ctx.fillText(label, p.x, p.y - p.r - 6);
    }
  }
  function tick() {
    if (view !== 'graph') return;
    step(); draw();
    G.raf = requestAnimationFrame(tick);
  }
  function pointer(e) { const r = canvas.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function hit(p) { for (let i = G.nodes.length - 1; i >= 0; i--) { const n = G.nodes[i]; if (Math.hypot(n.x - p.x, n.y - p.y) <= n.r + 5) return n; } return null; }
  canvas.addEventListener('pointerdown', (e) => { const n = hit(pointer(e)); if (n) { G.drag = n; G.moved = false; canvas.setPointerCapture(e.pointerId); canvas.style.cursor = 'grabbing'; G.alpha = Math.max(G.alpha, 0.5); } });
  canvas.addEventListener('pointermove', (e) => {
    const p = pointer(e);
    if (G.drag) { G.drag.x = p.x; G.drag.y = p.y; G.moved = true; G.alpha = Math.max(G.alpha, 0.4); }
    else { G.hover = hit(p); canvas.style.cursor = G.hover ? 'pointer' : 'grab'; }
  });
  canvas.addEventListener('pointerup', () => {
    if (G.drag && !G.moved && G.drag.kind === 'doc') openDoc(G.drag.doc_id);
    G.drag = null; canvas.style.cursor = 'grab';
  });
  window.addEventListener('resize', () => { if (view === 'graph') sizeCanvas(); });

  /* ---------- settings ---------- */
  function renderSettings() {
    $('#setName').value = me.name || '';
    $('#setMail').value = me.email;
    $('#planInfo').innerHTML = esc(t('plan.activeInfo')) + ' <b>' + esc(t('plan.name.' + me.plan)) + '</b>';
    const box = $('#planBtns');
    box.innerHTML = '';
    if (me.plan === 'free') {
      const pay = document.createElement('button');
      pay.className = 'btn'; pay.innerHTML = sticker('star', 'amber', 'sm') + '<span></span>';
      $('span', pay).textContent = t('plan.payme');
      pay.addEventListener('click', () => {
        if (cfg.paymeUrl) window.open(cfg.paymeUrl, '_blank', 'noopener');
        else toast(t('plan.noPayme'), true);
      });
      box.appendChild(pay);
    }
    const tg = document.createElement('a');
    tg.className = 'btn light'; tg.target = '_blank'; tg.rel = 'noopener'; tg.href = cfg.telegramUrl || 'https://t.me/';
    tg.innerHTML = sticker('telegram', 'blue', 'sm') + '<span></span>';
    $('span', tg).textContent = t('plan.corpBtn');
    box.appendChild(tg);
  }
  $('#profForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try { me = (await api('/api/me', { method: 'PATCH', body: JSON.stringify({ name: $('#setName').value }) })).user; renderUser(); toast(t('set.saved')); } catch (err) { fail(err); }
  });
  $('#delAcc').addEventListener('click', async () => {
    try { await api('/api/account', { method: 'DELETE', body: JSON.stringify({ confirm: $('#delConfirm').value.trim().toLowerCase() }) }); location.href = '/'; } catch (err) { fail(err); }
  });

  /* ---------- language change ---------- */
  window.addEventListener('langchange', async (e) => {
    if (!me) return;
    try { await api('/api/me', { method: 'PATCH', body: JSON.stringify({ lang: e.detail }) }); } catch (_) {}
    renderUser();
    $('#viewTitle').textContent = t('nav.' + view);
    go(view);
  });

  /* ---------- boot ---------- */
  (async function boot() {
    IC.hydrate();
    try { cfg = await api('/api/config'); } catch (_) {}
    try { me = (await api('/api/me')).user; } catch (_) { return; }
    // adopt the language saved on the account the first time the browser has no preference
    try { if (!localStorage.getItem('mg_lang') && me.lang) I18N.setLang(me.lang); } catch (_) {}
    I18N.apply();
    renderUser();
    const start = (location.hash || '').slice(1);
    go(['home', 'ask', 'add', 'library', 'graph', 'settings'].includes(start) ? start : 'home');
  })();
})();
