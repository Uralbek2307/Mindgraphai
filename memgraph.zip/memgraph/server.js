'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

// ---- tiny .env loader (no dependencies) ----
try {
  const envFile = path.join(__dirname, '.env');
  if (fs.existsSync(envFile)) {
    for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
      if (m && !line.trim().startsWith('#') && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
    }
  }
} catch (_) {}

const { db } = require('./lib/db');
const auth = require('./lib/auth');
const mem = require('./lib/memory');
const { htmlToText } = require('./lib/extract');
const { fetchPage } = require('./lib/net');

const PORT = +process.env.PORT || 3000;
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || '';
const PUBLIC = path.join(__dirname, 'public');
const IS_PROD = process.env.NODE_ENV === 'production' || (process.env.PUBLIC_URL || '').startsWith('https://');

let pdfParse = null;
try { pdfParse = require('pdf-parse'); } catch (_) { /* optional */ }

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json',
};

function secHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Content-Security-Policy',
    "default-src 'self'; script-src 'self' https://accounts.google.com/gsi/client; frame-src https://accounts.google.com/gsi/; " +
    "connect-src 'self' https://accounts.google.com/gsi/; img-src 'self' data: https:; style-src 'self' 'unsafe-inline' https://accounts.google.com/gsi/style; " +
    "font-src 'self' data:; base-uri 'self'; form-action 'self'; object-src 'none'");
  if (IS_PROD) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
}

function send(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}
const fail = (res, status, code) => send(res, status, { error: code });

function readBody(req, limit = 25 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > limit) { reject(Object.assign(new Error('too large'), { code: 'TOO_LARGE' })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch { reject(Object.assign(new Error('bad json'), { code: 'BAD_JSON' })); }
    });
    req.on('error', reject);
  });
}

function parseCookies(h) {
  const out = {};
  String(h || '').split(';').forEach((p) => { const i = p.indexOf('='); if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); });
  return out;
}

function setSession(res, uid) {
  const tok = auth.signSession(uid);
  res.setHeader('Set-Cookie', `mg_session=${encodeURIComponent(tok)}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${auth.SESSION_DAYS * 86400}${IS_PROD ? '; Secure' : ''}`);
}
function clearSession(res) {
  res.setHeader('Set-Cookie', `mg_session=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0${IS_PROD ? '; Secure' : ''}`);
}

const getUserById = (id) => db.prepare('SELECT * FROM users WHERE id=?').get(id);
const getUserByEmail = (e) => db.prepare('SELECT * FROM users WHERE email=?').get(e);
const pub = (u) => ({ id: u.id, email: u.email, name: u.name, picture: u.picture, plan: u.plan, lang: u.lang, created_at: u.created_at, hasPassword: !!u.pass_hash });
const okLang = (l) => (['uz', 'ru', 'en'].includes(l) ? l : 'uz');
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function currentUser(req) {
  const uid = auth.verifySession(parseCookies(req.headers.cookie).mg_session);
  return uid ? getUserById(uid) : null;
}

function sameOrigin(req) {
  const o = req.headers.origin;
  if (!o) return true;
  try { return new URL(o).host === req.headers.host; } catch { return false; }
}

// ------------------------------------------------------------------ API
async function api(req, res, url) {
  const method = req.method;
  const p = url.pathname;
  const ip = req.socket.remoteAddress || 'x';

  if (method !== 'GET' && !sameOrigin(req)) return fail(res, 403, 'FORBIDDEN_ORIGIN');

  if (p === '/api/config' && method === 'GET') {
    return send(res, 200, {
      googleClientId: GOOGLE_CLIENT_ID,
      aiMode: process.env.ANTHROPIC_API_KEY ? 'ai' : 'local',
      paymeUrl: process.env.PAYME_CHECKOUT_URL || '',
      telegramUrl: process.env.TELEGRAM_URL || 'https://t.me/',
      proPrice: 12,
    });
  }

  // ---------- auth ----------
  if (p === '/api/auth/register' && method === 'POST') {
    if (!auth.rateLimit('reg:' + ip, 10, 3600e3)) return fail(res, 429, 'RATE_LIMIT');
    const b = await readBody(req, 20_000);
    const email = String(b.email || '').trim().toLowerCase();
    const password = String(b.password || '');
    if (!EMAIL_RE.test(email) || email.length > 200) return fail(res, 400, 'BAD_EMAIL');
    if (password.length < 8 || password.length > 200) return fail(res, 400, 'WEAK_PASSWORD');
    if (getUserByEmail(email)) return fail(res, 409, 'EMAIL_TAKEN');
    const name = String(b.name || '').trim().slice(0, 80) || email.split('@')[0];
    const r = db.prepare('INSERT INTO users(email,name,pass_hash,lang,created_at) VALUES(?,?,?,?,?)').run(email, name, auth.hashPassword(password), okLang(b.lang), Date.now());
    setSession(res, Number(r.lastInsertRowid));
    return send(res, 200, { user: pub(getUserById(Number(r.lastInsertRowid))) });
  }

  if (p === '/api/auth/login' && method === 'POST') {
    if (!auth.rateLimit('login:' + ip, 20, 600e3)) return fail(res, 429, 'RATE_LIMIT');
    const b = await readBody(req, 20_000);
    const email = String(b.email || '').trim().toLowerCase();
    const u = getUserByEmail(email);
    if (!u || !auth.checkPassword(String(b.password || ''), u.pass_hash)) return fail(res, 401, u && !u.pass_hash ? 'USE_GOOGLE' : 'BAD_CREDENTIALS');
    setSession(res, u.id);
    return send(res, 200, { user: pub(u) });
  }

  if (p === '/api/auth/google' && method === 'POST') {
    if (!GOOGLE_CLIENT_ID) return fail(res, 503, 'GOOGLE_NOT_CONFIGURED');
    if (!auth.rateLimit('g:' + ip, 30, 600e3)) return fail(res, 429, 'RATE_LIMIT');
    const b = await readBody(req, 20_000);
    let g;
    try { g = await auth.verifyGoogleIdToken(b.credential, GOOGLE_CLIENT_ID); } catch (e) { console.warn('google verify failed:', e.message); return fail(res, 401, 'GOOGLE_FAILED'); }
    let u = db.prepare('SELECT * FROM users WHERE google_id=?').get(g.sub) || getUserByEmail(g.email);
    if (!u) {
      const r = db.prepare('INSERT INTO users(email,name,picture,google_id,lang,created_at) VALUES(?,?,?,?,?,?)').run(g.email, g.name || g.email.split('@')[0], g.picture, g.sub, okLang(b.lang), Date.now());
      u = getUserById(Number(r.lastInsertRowid));
    } else {
      db.prepare('UPDATE users SET google_id=?, picture=CASE WHEN picture=\'\' THEN ? ELSE picture END, name=CASE WHEN name=\'\' THEN ? ELSE name END WHERE id=?').run(g.sub, g.picture, g.name, u.id);
      u = getUserById(u.id);
    }
    setSession(res, u.id);
    return send(res, 200, { user: pub(u) });
  }

  if (p === '/api/auth/logout' && method === 'POST') { clearSession(res); return send(res, 200, { ok: true }); }

  // ---------- admin: set plan (call from your Payme webhook / manually) ----------
  if (p === '/api/admin/plan' && method === 'POST') {
    const key = process.env.ADMIN_KEY;
    if (!key || req.headers['x-admin-key'] !== key) return fail(res, 403, 'FORBIDDEN');
    const b = await readBody(req, 5000);
    if (!['free', 'pro', 'corporate'].includes(b.plan)) return fail(res, 400, 'BAD_PLAN');
    const r = db.prepare('UPDATE users SET plan=? WHERE email=?').run(b.plan, String(b.email || '').toLowerCase());
    return send(res, 200, { updated: r.changes });
  }

  // ---------- everything below needs a session ----------
  const user = currentUser(req);
  if (!user) return fail(res, 401, 'UNAUTHORIZED');

  if (p === '/api/me' && method === 'GET') return send(res, 200, { user: pub(user) });
  if (p === '/api/me' && method === 'PATCH') {
    const b = await readBody(req, 5000);
    if (b.lang) db.prepare('UPDATE users SET lang=? WHERE id=?').run(okLang(b.lang), user.id);
    if (typeof b.name === 'string' && b.name.trim()) db.prepare('UPDATE users SET name=? WHERE id=?').run(b.name.trim().slice(0, 80), user.id);
    return send(res, 200, { user: pub(getUserById(user.id)) });
  }

  if (p === '/api/stats' && method === 'GET') return send(res, 200, mem.stats(user));

  if (p === '/api/docs' && method === 'GET') {
    const q = (url.searchParams.get('q') || '').trim();
    if (q) {
      const hits = mem.search(user.id, q, 12);
      const seen = new Set(); const out = [];
      for (const h of hits) { if (seen.has(h.doc_id) || (h.score < 0.1 && h.lex < 0.5)) continue; seen.add(h.doc_id); out.push({ id: h.doc_id, title: h.title, type: h.type, source: h.source, created_at: h.created_at, snippet: h.text.slice(0, 200) }); }
      return send(res, 200, { docs: out });
    }
    const docs = db.prepare('SELECT id,title,type,source,created_at, substr(content,1,200) snippet, length(content) size FROM docs WHERE user_id=? ORDER BY created_at DESC LIMIT 500').all(user.id);
    return send(res, 200, { docs });
  }

  let m;
  if ((m = p.match(/^\/api\/docs\/(\d+)$/))) {
    const id = +m[1];
    if (method === 'GET') {
      const d = db.prepare('SELECT id,title,type,source,content,created_at FROM docs WHERE id=? AND user_id=?').get(id, user.id);
      if (!d) return fail(res, 404, 'NOT_FOUND');
      const ents = db.prepare('SELECT e.name,e.kind FROM doc_entities de JOIN entities e ON e.id=de.entity_id WHERE de.doc_id=? ORDER BY de.weight DESC').all(id);
      return send(res, 200, { doc: d, entities: ents });
    }
    if (method === 'DELETE') return mem.deleteDoc(user.id, id) ? send(res, 200, { ok: true }) : fail(res, 404, 'NOT_FOUND');
  }

  if (p === '/api/docs' && method === 'POST') {
    if (!auth.rateLimit('add:' + user.id, 120, 3600e3)) return fail(res, 429, 'RATE_LIMIT');
    const b = await readBody(req);
    try {
      let doc;
      if (b.type === 'url') {
        let u; try { u = new URL(String(b.url || '')); } catch { return fail(res, 400, 'BAD_URL'); }
        let page;
        try { page = await fetchPage(u.toString()); } catch (e) { return send(res, 422, { error: 'FETCH_FAILED', detail: e.message }); }
        const isHtml = /html/i.test(page.contentType) || /^\s*<(!doctype|html)/i.test(page.body);
        const parsed = isHtml ? htmlToText(page.body) : { title: '', text: page.body };
        doc = { title: b.title || parsed.title || u.hostname, type: 'link', source: page.finalUrl, content: parsed.text };
      } else if (b.type === 'file') {
        const name = String(b.filename || 'file').slice(0, 160);
        const ext = path.extname(name).toLowerCase();
        let text;
        if (ext === '.pdf') {
          if (!pdfParse) return fail(res, 501, 'PDF_NOT_INSTALLED');
          const buf = Buffer.from(String(b.base64 || ''), 'base64');
          try { text = (await pdfParse(buf)).text; } catch { return fail(res, 422, 'PDF_UNREADABLE'); }
        } else if (['.html', '.htm'].includes(ext)) {
          text = htmlToText(String(b.content || '')).text;
        } else {
          text = String(b.content || '');
          if (ext === '.srt' || ext === '.vtt') text = text.replace(/^\d+\s*$/gm, '').replace(/^[\d:.,\- >]+$/gm, '').replace(/^WEBVTT.*$/m, '');
        }
        doc = { title: b.title || name.replace(/\.[^.]+$/, ''), type: ext === '.pdf' ? 'pdf' : 'file', source: name, content: text };
      } else {
        doc = { title: b.title, type: ['note', 'email', 'meeting'].includes(b.kind) ? b.kind : 'note', source: '', content: b.content };
      }
      const r = mem.addDoc(user, doc);
      return send(res, 200, r);
    } catch (e) {
      if (e.code === 'EMPTY') return fail(res, 400, 'EMPTY');
      if (e.code === 'LIMIT_DOCS') return fail(res, 402, 'LIMIT_DOCS');
      throw e;
    }
  }

  if (p === '/api/ask' && method === 'POST') {
    const b = await readBody(req, 20_000);
    const q = String(b.question || '').trim().slice(0, 1000);
    if (q.length < 2) return fail(res, 400, 'EMPTY');
    if (!auth.rateLimit('ask:' + user.id, 60, 600e3)) return fail(res, 429, 'RATE_LIMIT');
    const st = mem.stats(user);
    if (st.limits.asksPerDay !== null && st.asksToday >= st.limits.asksPerDay) return fail(res, 402, 'LIMIT_ASKS');
    return send(res, 200, await mem.ask(user, q, okLang(b.lang || user.lang)));
  }

  if (p === '/api/history' && method === 'GET') {
    const rows = db.prepare('SELECT id,question,answer,sources,mode,created_at FROM chats WHERE user_id=? ORDER BY created_at DESC LIMIT 50').all(user.id);
    return send(res, 200, { chats: rows.map((r) => ({ ...r, sources: JSON.parse(r.sources) })) });
  }
  if (p === '/api/history' && method === 'DELETE') { db.prepare('DELETE FROM chats WHERE user_id=?').run(user.id); return send(res, 200, { ok: true }); }

  if (p === '/api/graph' && method === 'GET') return send(res, 200, mem.graph(user.id));

  if (p === '/api/export' && method === 'GET') {
    const out = {
      exported_at: new Date().toISOString(), user: pub(user),
      docs: db.prepare('SELECT id,title,type,source,content,created_at FROM docs WHERE user_id=?').all(user.id),
      chats: db.prepare('SELECT question,answer,created_at FROM chats WHERE user_id=?').all(user.id),
    };
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Disposition': 'attachment; filename="memgraph-export.json"', 'Cache-Control': 'no-store' });
    return res.end(JSON.stringify(out, null, 2));
  }

  if (p === '/api/account' && method === 'DELETE') {
    const b = await readBody(req, 2000);
    if (b.confirm !== user.email) return fail(res, 400, 'CONFIRM_MISMATCH');
    db.prepare('DELETE FROM users WHERE id=?').run(user.id);
    clearSession(res);
    return send(res, 200, { ok: true });
  }

  return fail(res, 404, 'NOT_FOUND');
}

// ------------------------------------------------------------------ static
function serveStatic(req, res, url) {
  let p = decodeURIComponent(url.pathname);
  if (p === '/') p = '/index.html';
  if (p === '/app') p = '/app.html';
  const file = path.normalize(path.join(PUBLIC, p));
  if (!file.startsWith(PUBLIC + path.sep)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Not found'); }
    const ext = path.extname(file).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300' });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  });
}

const server = http.createServer(async (req, res) => {
  secHeaders(res);
  const url = new URL(req.url, 'http://localhost');
  try {
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    return serveStatic(req, res, url);
  } catch (e) {
    if (e.code === 'TOO_LARGE') return fail(res, 413, 'TOO_LARGE');
    if (e.code === 'BAD_JSON') return fail(res, 400, 'BAD_JSON');
    console.error(e);
    if (!res.headersSent) return fail(res, 500, 'SERVER_ERROR');
    res.end();
  }
});

server.listen(PORT, () => {
  console.log(`MemGraph running on http://localhost:${PORT}`);
  console.log(`  Google sign-in : ${GOOGLE_CLIENT_ID ? 'ON' : 'OFF (set GOOGLE_CLIENT_ID in .env)'}`);
  console.log(`  AI answers     : ${process.env.ANTHROPIC_API_KEY ? 'Claude API' : 'local extractive mode (set ANTHROPIC_API_KEY for generative answers)'}`);
  console.log(`  PDF import     : ${pdfParse ? 'ON' : 'OFF (run: npm install)'}`);
});
