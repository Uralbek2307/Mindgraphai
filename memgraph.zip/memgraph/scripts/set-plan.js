'use strict';
// Usage: npm run set-plan -- user@example.com pro
const { db } = require('../lib/db');
const [email, plan] = process.argv.slice(2);
if (!email || !['free', 'pro', 'corporate'].includes(plan)) {
  console.log('Usage: npm run set-plan -- <email> <free|pro|corporate>');
  process.exit(1);
}
const r = db.prepare('UPDATE users SET plan=? WHERE email=?').run(plan, email.toLowerCase());
console.log(r.changes ? `OK: ${email} -> ${plan}` : 'User not found');
