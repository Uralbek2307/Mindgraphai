# MemGraph — Shaxsiy va korporativ AI-xotira (Second Brain)

Xatlar, qaydlar, PDF, havolalar va uchrashuv yozuvlarini bitta bilimlar grafiga bogʻlaydi va
savolga manbalari bilan javob beradi. Interfeys: **oʻzbek / rus / ingliz**. Kirish: **Google** yoki email+parol.

## 1. Ishga tushirish (3 daqiqa)

Kerak: **Node.js 22.13 yoki yangi** (https://nodejs.org).

```bash
npm install            # PDF oʻqish paketini oʻrnatadi
cp .env.example .env   # Windows: copy .env.example .env
npm start
```
Brauzerda oching: http://localhost:3000

Email+parol bilan roʻyxatdan oʻtish darhol ishlaydi. **Google bilan kirish uchun 2-bandni bajaring.**

## 2. Google bilan kirishni yoqish

1. https://console.cloud.google.com → loyiha yarating → **APIs & Services → OAuth consent screen** (External, nom va email kiriting).
2. **Credentials → Create credentials → OAuth client ID → Web application**.
3. **Authorized JavaScript origins** ga qoʻshing: `http://localhost:3000` va keyin haqiqiy domeningiz (`https://sizning-domen.uz`).
4. Hosil boʻlgan **Client ID** ni `.env` dagi `GOOGLE_CLIENT_ID=` ga qoʻying, serverni qayta ishga tushiring.

Server Google ID tokenini Googleʻning ochiq kalitlari bilan oʻzi tekshiradi (imzo, audience, muddat, email tasdigʻi).

## 3. AI javoblari (ixtiyoriy)

`ANTHROPIC_API_KEY` boʻlmasa, MemGraph oʻzining mahalliy qidiruvi bilan javob beradi (maʼnoli qidiruv + eng mos
jumlalarni manbalari bilan chiqaradi). Kalit qoʻyilsa, javoblar Claude orqali yoziladi — faqat topilgan xotira
boʻlaklari yuboriladi va javob faqat shularga asoslanadi.

## 4. Pro toʻlov (Payme) va tariflar

* `.env` ga `PAYME_CHECKOUT_URL` (toʻlov sahifangiz) va `TELEGRAM_URL` (korporativ soʻrovlar) yozing.
* Toʻlov kelgach foydalanuvchini Pro qiling:
  `npm run set-plan -- user@mail.com pro`
  yoki: `curl -X POST https://domen/api/admin/plan -H "x-admin-key: ADMIN_KEY" -H "content-type: application/json" -d '{"email":"user@mail.com","plan":"pro"}'`
* Diqqat: Payme bilan **avtomatik** faollashtirish uchun Payme Merchant API (webhook) ulanishi kerak — bu loyihada
  tayyor emas; hozircha faollashtirish yuqoridagi buyruq orqali qoʻlda. `/api/admin/plan` ni webhookingizdan chaqirish mumkin.

Limitlar: Bepul — 100 hujjat va kuniga 20 savol; Pro/Korporativ — cheksiz.

## 5. Internetga chiqarish

Maʼlumotlar SQLite faylida (`data/memgraph.db`), shuning uchun **doimiy disk** kerak: VPS (eng oson), Railway/Render/Fly.io
(Volume bilan) yoki Docker:

```bash
docker build -t memgraph .
docker run -d -p 3000:3000 -v memgraph-data:/data --env-file .env memgraph
```
Vercel kabi serverless xostingda **ishlamaydi** (fayl tizimi doimiy emas). HTTPS uchun Nginx/Caddy orqasiga qoʻying va
`.env` da `NODE_ENV=production`, `PUBLIC_URL=https://domen`, `SESSION_SECRET=...` ni belgilang. `data/` ni zaxiralab turing.

## Tuzilma

```
server.js          HTTP server + API (kutubxonasiz)
lib/               db (SQLite), auth (Google, scrypt, sessiya), embed (mahalliy vektor), extract (graf), memory (qidiruv/javob/graf)
public/            sayt: index.html (landing), app.html (kabinet), js/, css/
scripts/set-plan.js
```

## Xavfsizlik

Parollar scrypt bilan, sessiya imzolangan HttpOnly cookie, CSRF (Origin tekshiruvi), tezlik limiti, havola qoʻshishda
SSRF himoyasi (ichki IP manzillar bloklanadi), CSP sarlavhalari, hisobni va maʼlumotni oʻchirish/eksport.
